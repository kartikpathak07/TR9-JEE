package com.hidden.demo;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
										throws ServletException, IOException {
		String name= req.getParameter("clientName");
		String education = req.getParameter("education");
		PrintWriter out = resp.getWriter();
		out.print("Welcome!!!! "+name+"<br>");
		out.print("You have entered your education as : "+education);
		out.print("<form action=\"ValidateServlet\">");
		out.print("<input type=\"hidden\" name=\"clientName\" "
					+ "value=\""+name+"\"/>");
		out.print("<input type=submit name=submit value=submit/>");
		out.print("</form>");
	}

	
}





